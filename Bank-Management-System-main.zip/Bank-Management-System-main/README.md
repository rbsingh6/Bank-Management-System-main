# Bank Management System

I have created a bank management system that works as a record system. It assists users with different actions for their accounts, such as depositing money, withdrawing money, and viewing their balance. The administrator can add or delete accounts and view account details of any user. The system tracks all the transactions and deposits from all the users for more accuracy in the system. All of this is implemented using different classes, members, and header files.
